
// Fragen Editor 1.1

 
function get_questions() {

  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Alanin', 'Ala'], 4, 'testbilder/030303.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Arginin', 'Arg'], 4, 'testbilder/030308.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Asparagin', 'Asn'], 4, 'testbilder/030311.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Asparagins�ure', 'Asp'], 4, 'testbilder/030314.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Cystein', 'Cys'], -4, 'testbilder/030315.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Cystin', '(Cys)2'], -4, 'testbilder/030316.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Glutamin', 'Gln'], 4, 'testbilder/030321.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Glutamins�ure', 'Glu'], 4, 'testbilder/030307.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Glycin', 'Gly'], 4, 'testbilder/030320.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Histidin', 'His'], 4, 'testbilder/030319.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Isoleucin', 'Ile'], 4, 'testbilder/030318.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Leucin', 'Leu'], 4, 'testbilder/030302.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Lysin', 'Lys'], 4, 'testbilder/030304.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Methionin', 'Met'], 4, 'testbilder/030306.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Phenylalanin', 'Phe'], 4, 'testbilder/030313.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Prolin', 'Pro'], 4, 'testbilder/030312.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Serin', 'Ser'], 4, 'testbilder/030301.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Threonin', 'Thr'], 4, 'testbilder/030317.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Tryptophan', 'Trp'], 4, 'testbilder/030310.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Tyrosin', 'Tyr'], 4, 'testbilder/030309.gif' ]) ;
  load_question(['Benennen Sie die abgebildete Aminos&auml;ure', [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], [' ', ' '], ['Valin', 'Val'], 4, 'testbilder/030305.gif' ]) ;
  
}
